const onid = '[enter onid here]';
const db_pw = '[enter db password here]';

export {onid, db_pw}